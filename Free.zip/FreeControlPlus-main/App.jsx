
export default function App() {
  return (
    <div className="app-container">
      <h1>🔧 FreeControl+</h1>
      <p>Bienvenue dans votre centre de contrôle réseau.</p>
    </div>
  )
}
